#!/bin/bash
part11=$(ls /home/suzen/part1/)
part22=$(ls /home/john/Documents/part2/)
part33=$(ls /home/john/Desktop/part3/)
echo  $part11$part22$part33
