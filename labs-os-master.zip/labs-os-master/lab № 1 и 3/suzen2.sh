#!/bin/bash
cat ./*
