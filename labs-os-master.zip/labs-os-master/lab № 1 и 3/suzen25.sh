#!/bin/bash
ls -all
cat flag
