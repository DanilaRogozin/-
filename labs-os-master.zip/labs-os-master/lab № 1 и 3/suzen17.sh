#!/bin/bash
ls -all
part=$(ls -a | egrep -o '[a-zA-Z0-9]{28}')
echo $part
