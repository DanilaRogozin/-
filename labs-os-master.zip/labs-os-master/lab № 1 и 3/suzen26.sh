#!/bin/bash
less flag
