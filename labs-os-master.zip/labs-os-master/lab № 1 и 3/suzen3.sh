#!/bin/bash
while read LINE;
do echo "$LINE";
done < ./-diary.txt-
