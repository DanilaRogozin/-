#!/bin/bash
cat diary.txt
