# Часть №2 По заданию отключается один SSD,по заданию мы заменяем его и с помощью LVM сохраняем все данные и копируем на новый диск. (part2)
- Скриншот 2.1 - реакция ос на удаление ssd1.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%202/2.1.png)

- Скриншот 2.2 - виртуальная машина работает.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%202/2.2.png)

- Скриншот 2.3 - проверка статуса RAID после удаление sdd1.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%202/2.3.png)

- Скриншот 2.4 - реакция виртуальной машины на добавление ssd3.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%202/2.4.png)

- Скриншот 2.5 - добавление в RAID ssd3.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%202/2.5.png)

- Скриншот 2.6 - результат в mdstat.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%202/2.6.png)

- Скриншот 2.7 - результат задания № 2.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%202/2.7.png)
