# Часть №3 В этой части по заданию отключается еще один SSD, мы заменяем его на новый sdd на 7 gb и добавляем 2 новых HDD.
 - С помощью LVM и RAID спасаем данные и включаем новый SSD в VG. (part3)
- Скриншот 3.1 - информация о дисках после удаления ssd2.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.1.png)
- Скриншот 3.2 - информация в mdstat после удаления ssd2.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.2.png)
- Скриншот 3.3 - информация после добавления ssd4.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.3.png)
- Скриншот 3.4 - информация после копирования файлов в таблицу на ssd4.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.4.png)
- Скриншот 3.5 - информация после монтирования boot на ssd4.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.5.png)
- Скриншот 3.6 - информация после создания нового RAID массива.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.6.png)
- Скриншот 3.7 - изменение pvs до и после создания нового zip тома.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.7.png)
- Скриншот 3.8 - информация о дисках после создания zip тома.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.8.png)
- Скриншот 3.9 - var, root, var находятся на md0.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.9.png)
- Скриншот 3.10 - результаты после перемещения LV.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.10.png)
- Скриншот 3.11 - информация о дисках только после добавления всех новых.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.11.png)
- Скриншот 3.12 - информация о дисках после копирования таблицы файлов и sda1.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.12.png)
- Скриншот 3.13 - информация после добавления ssd5 в RAID и увеличения размеров на общих дисках.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.13.png)
- Скриншот 3.14 - размер sda(e)2=md127.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.14.png)
- Скриншот 3.15 - размер VG увеличился.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.15.png)
- Скриншот 3.16 - информация об увеличении размеров root и var.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.16.png)
- Скриншот 3.17 - конечный результат работы с ssd.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.17.png)
- Скриншот 3.18 - информация о дисках после создания логического тома.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.18.png)
- Скриншот 3.19 - информация о дисках после форматирования разделов.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.19.png)
- Скриншот 3.20 - информация о дисках после переформатирования var-логов. Image alt
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.20.png)
- Скриншот 3.21 - изменение файла fstab.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.21.png)
- Скриншот 3.22 - последняя проверка pvs, lvs, vgs.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.22.png)
- Скриншот 3.23 - послежняя проверка и информация о дисках.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.23.png)
- Скриншот 3.24 - последняя информация о RAID.
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/lab%20№%202/part%203/3.24.png)
