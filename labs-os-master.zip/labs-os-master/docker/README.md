# Лабораторная работа №4.
- ФИО: Шиманская Галина Владимировна
- Группа: ББСО-04-18
![Image alt](https://github.com/galina-shimanskaya/labs-os/blob/master/docker/screenshot.png)
